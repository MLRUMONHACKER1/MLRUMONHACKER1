import requests
import logging
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# Set up logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

# Your API Key for remove.bg
REMOVE_BG_API_KEY = "YOUR_API_KEY"

# Function to remove background
async def remove_bg(photo_path):
    try:
        with open(photo_path, 'rb') as image_file:
            response = requests.post(
                'https://api.remove.bg/v1.0/removebg',
                files={'image_file': image_file},
                data={'size': 'auto'},
                headers={'X-Api-Key': REMOVE_BG_API_KEY},
            )
            if response.status_code == 200:
                with open("no_bg.png", 'wb') as out:
                    out.write(response.content)
                return "no_bg.png"
            else:
                return None
    except Exception as e:
        print("Exception during remove_bg:", e)
        return None

# Function to handle /start command
def start(update: Update, context: CallbackContext) -> None:
    update.message.reply_text('Hello! Send me an image, and I will remove its background for you.')

# Function to handle photo messages
def handle_photo(update: Update, context: CallbackContext) -> None:
    photo = update.message.photo[-1].get_file()
    photo.download("received_photo.jpg")
    result = remove_bg("received_photo.jpg")
    
    if result:
        update.message.reply_text("Background removed!")
        update.message.reply_photo(photo=open(result, 'rb'))
    else:
        update.message.reply_text("Sorry, I couldn't remove the background. Please try again later.")

# Main function to set up the bot
def main() -> None:
    # Replace 'YOUR_API_TOKEN' with your actual bot API token
    updater = Updater("YOUR_API_TOKEN")
    dispatcher = updater.dispatcher

    # Register handlers
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(MessageHandler(Filters.photo, handle_photo))

    # Start the bot
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
    